
# 파악해야 하는 것. 
# 1: 변수의 유형
# 2: 변수의 길이
df[,sapply(.SD, \(x){
  type  = class(x)
  unique_len = uniqueN(x)
})]


makeBaselineTable = function(data, include, dicho_vars, by){
  require(gtsummary)
  test = ifelse(uniqueN(df[[by]]) > 2,"aov","t.test")
  tbl1 = gtsummary::tbl_summary(
    data=data,
    by=by,
    include = include,
    missing = 'no',
    statistic = list(
      all_continuous() ~ "{mean} ± {sd}",
      all_categorical() ~ "{n} ({p})",
      c(AST, ALT) ~ "{median} [{p25}–{p75}] ({min},{max})",
      c(TZ_ICUAdm_gap_hour, ICU_LOS, Hospital_LOS) ~ "{median} ({p25}—{p75})"
    ),
    type = list(
      SOFA_Renal ~ "continuous",
      dicho_vars ~ 'dichotomous'
    ),
    value = list(
      SEX ~ 'Male'
    ),
    digits = list(
      all_continuous() ~ 1,
      all_categorical() ~ c(0,1)
    )
  ) |> 
    add_overall() |> 
    add_p(pvalue_fun = ~style_pvalue(., digits=3),
          test = list(
            all_continuous() ~ "aov"
          )) |> 
    modify_footnote(everything() ~ NA)
  
  if(length(unique(data[[by]]))==2) tbl1 = tbl1 |> modify_table_body(~.x |> relocate(stat_2, .after=stat_0))
  
  return(tbl1)
}


# univariable regression
# OR (HR), CI, p-val
uni_reg = function(data, vars, y, type, digit=3, time=NULL) {
  tbls = lapply(vars, \(var) {
    if(type %in% c("glm","lr","LR","logistic")){
      form = paste0(y, "~", var)
      fit = glm(as.formula(form), family=binomial, data=data)
      est = coef(fit) |> exp()
      ci = suppressMessages(confint(fit)) |> exp()  |> sapply(`[[`,1)
      p = summary(fit)$coefficients[,4]
      data.table(
        variable = var,
        `OR (95% CI)` = paste0(format(round(est, digit), nsmall=2), " (",
                                paste0(format(round(ci[2],digit),nsmall=2),"—",
                                       format(round(ci[4], digit), nsmall=2)),")"),
        p.value = ifelse(p <0.001, "<0.001", round(p,4))
      )[2,]
    } else if (type %in% c("multi","multiLR","multinomial")) {
      form = paste0(y, "~", var)
      fit = vglm(as.formula(form), multinomial(refLevel="Non-AKI"), data=data)
      smry = summaryvglm(fit)
      rst_tbl  = as.data.table(
        cbind(
          covariate = var,
          OR_CI = paste0(
                       format(round(exp(coef(fit)),2),2), " (",
                       format(round(exp(confint(fit))[,1],2),2), "—",
                       format(round(exp(confint(fit))[,2],2),2), ")"),
          pval = ifelse(smry@coef3[,4] < 0.001,"0.001", round(smry@coef3[,4],4))
        ),
        keep.rowname=T
      )[3:4,]
    } else if (type %in% c("cox","coxph")){
      if(is.null(time)) stop ("No time variable!")
      form = paste0("Surv(",time,",",y,")~",var)
      fit = coxph(as.formula(form), data=data) |> summary()
      est = fit$conf.int[1]
      ci = fit$conf.int[3:4]
      p = fit$coefficients[5]
      data.table(
        variable = var,
        `HR (95% CI)` = paste0(round(est,3), " (",paste0(round(ci[1],digit),"—",round(ci[2], digit)),")"),
        p.value = ifelse(p <0.001, "<0.001", format(round(p,4),4))
      )
    }
  })
  tbls |> setNames(vars) |> 
    do.call(what="rbind")
}

uni_reg(data=df, vars=vars, y="inhos_mortality", type="glm")
uni_reg(data=df, vars=c("SEX","Age"), y="inhos_mortality", type="coxph", time="Hospital_LOS")

# multivariable regression
multi_reg = function(data, vars, y, type, digit=2, time = NULL) {
  if (type %in%  c("glm","lr","logistic")) {
    form = paste0(y,"~",paste0(vars, collapse=" + "))
    fit = glm(as.formula(form), family=binomial, data)
    est = coef(fit) |> exp()
    ci = suppressMessages(confint(fit)) |> exp()
    p = summary(fit)$coefficients[,4]
    rst_tbl = data.table(
      variable = c("Intercept", vars),
      `OR (95% CI)` = paste0(format(round(est, digit),nsmall=2), " (",
                             paste0(format(round(ci[,1], digit),nsmall=2),"—",
                                    format(round(ci[,2], digit),nsmall=2)),")"),
      p.value = ifelse(p <0.001, "<0.001", round(p, 4))
    )
  } else if (type=="coxph") {
    form = paste0("Surv(",time,",",y,")~",paste0(vars))
    fit = coxph(as.formula(form), data)
  } else if (type %in% c("multinomial","multi")){
    form = paste0(y, "~", paste0(vars, collapse="+"))
    fit = vglm(as.formula(form), multinomial(refLevel="Non-AKI"), data=df)
    smry = summaryvglm(fit)
    coef = coef(fit)
    ci = confint(fit)
    p = smry@coef3[,4]
    coefs_no_const = coef[!names(coef) %like% "Intercept"]; print(length(coefs_no_const))
    cis_no_const = ci[!rownames(ci) %like% "Intercept",]; print(length(cis_no_const[,1]))
    ps_no_const = p[!names(p) %like% "Intercept"]; print(length(ps_no_const))
    rst_tbl  = as.data.table(
      cbind(
        OR_CI = paste0(
                       format(round(exp(coefs_no_const),2),2), " (",
                       format(round(exp(cis_no_const)[,1],2),2), "—",
                       format(round(exp(cis_no_const)[,2],2),2), ")"),
        pval = ifelse(ps_no_const < 0.001, "<0.001", round(ps_no_const,4))
      ),
      keep.rowname=TRUE
    )
  }
  return(rst_tbl)
}


